import { Controller, Get, Param, Query, Req, UseGuards } from "@nestjs/common";
import { GetDashboardOverviewUseCase } from "./application/use-cases/get-dashboard-overview/get-dashboard-overview.use-case";
import { GetDashboardConnectionMetricsHistoryUseCase } from "./application/use-cases/get-dashboard-connection-metrics-history/get-dashboard-connection-metrics-history.use-case";
import { JwtAuthGuard } from "../auth/guards/jwt-auth.guard";

@Controller("dashboard")
export class DashboardController {
  constructor(
    private readonly getDashboardOverviewUseCase: GetDashboardOverviewUseCase,
    private readonly getDashboardConnectionMetricsHistoryUseCase: GetDashboardConnectionMetricsHistoryUseCase,
  ) {}

  @UseGuards(JwtAuthGuard)
  @Get("overview")
  async overview(@Req() request: any) {
    const userId = request.user.userId;

    return this.getDashboardOverviewUseCase.execute({ userId });
  }

  @UseGuards(JwtAuthGuard)
  @Get("connections/:connectionId/metrics-history")
  async connectionMetricsHistory(
    @Req() request: any,
    @Param("connectionId") connectionId: string,
    @Query("startDate") startDate?: string,
    @Query("endDate") endDate?: string,
  ) {
    const userId = request.user.userId;

    return this.getDashboardConnectionMetricsHistoryUseCase.execute({
      userId,
      connectionId,
      startDate,
      endDate,
    });
  }
}
