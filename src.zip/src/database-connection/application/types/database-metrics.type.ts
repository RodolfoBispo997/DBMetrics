export type DatabaseMetric = {
  databaseVersion: string;
  tablesCount: number;
  databaseSize: number;
  activeConnections: number;
};
